/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Homework;
import java.util.Scanner;
/**
 *
 * @author haziq
 */
public class two {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter year: ");
        int year = sc.nextInt();
        if (year<1)
            System.out.println("Invalid");
        else {
            boolean leap = year%400==0 ||(year%4==0&&year%100!=0);
            System.out.println(leap?"Leap year":"Common year");
        }
    }
}
