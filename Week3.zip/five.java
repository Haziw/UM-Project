/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Homework;
import java.util.Scanner;
/**
 *
 * @author haziq
 */
public class five {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter first name: ");
        String word1 = sc.nextLine();
        System.out.print("Enter second name: ");
        String word2 = sc.nextLine();
        if (word1.equalsIgnoreCase(word2))
            System.out.println("Same name");
        else {
            if (word1.compareTo(word2)>0)
                System.out.print(word1+" "+word2);
            else
                System.out.println(word2+" "+word1);
        }
    }
}
