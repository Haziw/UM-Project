/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Homework;
import java.util.Scanner;
/**
 *
 * @author haziq
 */
public class three {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter age: ");
        int age = sc.nextInt();
        sc.nextLine();
        System.out.print("Are you a student(yes/no): ");
        String stuStat = sc.nextLine();
        if (age<0||age>120||!stuStat.equalsIgnoreCase("yes")||!stuStat.equalsIgnoreCase("no"))
            System.out.println("Invalid");
        else if (age<12||age>=60)
            System.out.println("Ticket price: RM8");
        else if (stuStat.equalsIgnoreCase("yes"))
            System.out.print("Ticket price: RM10");
        else 
            System.out.println("Ticket price: RM 15");
        
    }
}
