/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Homework;
import java.util.Scanner;
/**
 *
 * @author haziq
 */
public class one {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter mark: ");
        int mark = sc.nextInt();
        if(mark<0||mark>100)
            System.out.println("Mark is invalid");
        else if (mark>79)
            System.out.println("Grade A");
        else if (mark>64)
            System.out.println("Grade B");
        else if (mark>49)
            System.out.println("Grade C");
        else
            System.out.println("Grade F");
        sc.close();
    }
}
//Validation comes before grade thresholds to prevent logic error.
//Programmer sometime could sometime make a mistake in coding that will cause this error.