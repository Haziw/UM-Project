/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Homework;
import java.util.Scanner;
/**
 *
 * @author haziq
 */
public class four {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter first number: ");
        double num1 = sc.nextDouble();
        System.out.print("Enter second number: ");
        double num2 = sc.nextDouble();
        System.out.print("Enter operator: ");
        char ope = sc.next().charAt(0);
        double ans;
        switch (ope) {
            case '+':
                ans = num1+num2;
                System.out.println("Answer: "+ans);
                break;
            case '-':
                ans = num1-num2;
                System.out.println("Answer: "+ans);
                break;
            case '*':
                ans = num1*num2;
                System.out.println("Answer: "+ans);
                break;
            case '/':
                if (num2==0)
                    System.out.println("Cannot divide by zero");
                else {
                    ans = num1/num2;
                    System.out.println("Answer: "+ans);
                }
                break;
            default:
                System.out.print("Invalid operator");
                break;
        }    
    }
}
